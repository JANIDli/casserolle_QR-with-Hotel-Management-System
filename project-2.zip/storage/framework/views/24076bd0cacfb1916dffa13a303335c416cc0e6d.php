<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Document</title>
</head>
<body>
    <form action="/contact" method="post">
    <?php echo csrf_field(); ?>
    <input type="text" name="name"><br>
    <input type="text" name="email"><br>

    <input type="text" name="comment"><br>
    <button type="submit">Submit</button>    
</form>
</body>
</html><?php /**PATH C:\Users\janith\Desktop\Continure Oreginal\project-2\resources\views/testing/testing.blade.php ENDPATH**/ ?>