<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" type="text/css" href= "<?php echo e(url('/styles/bootstrap-4.1.2/bootstrap.min.css')); ?>">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Admin</title>
</head>
<body>
    <div class="container">
        <div class="row">
			<div class="col-12">
				<div class="bg-info pl-4 pr-4 pt-2 pb-2">
					<h3 class="display-4 fs-1" style="font-size:30px;">Admin Panel</h3>
				</div>
			</div>
            <div class="col-12">
				<div class="pr-4 pl-4 shadow-sm" style="background:#f5fdff;">
					<div class="p-4 shadow-sm mt-4 bg-white">
						<form action="/menu/create" method="POST" enctype="multipart/form-data">
			                <?php echo csrf_field(); ?>
			                <h5>Add menu</h5>
			                <input type="text" name="name" placeholder="Menu" class="form-control">
							<div class="mt-3">
								<input type="file" name="file">
							</div>
			                <button type=submit class="btn btn-sm btn-primary mt-4">Add</button>
			            </form>
					</div>

					<div class="p-4 shadow-sm mt-4 bg-white">
						<form action="/food/create" method="POST" class="mt-4 mb-4" enctype="multipart/form-data">
		               	 	<?php echo csrf_field(); ?>
		                    <div>
								<h5>Add food</h5>
							</div>
		                    <div class="mt-3">
								<input class="form-control" type="text" name="name" placeholder="Name">
							</div>
							<div class="mt-3">
								<select name="menu_id" class="form-control">
									<?php $__currentLoopData = $menus; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $menu): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
										<option value="<?php echo e($menu->id); ?>"><?php echo e($menu->name); ?></option>
									<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
								</select>
							</div>
		                    <div class="mt-3">
								<textarea class="form-control" name="description" id="" cols="30" rows="10" placeholder="Description"></textarea>
							</div>
		                    <div class="mt-3">
								<input class="form-control" type="number" name="price" placeholder="price">
							</div>
		                    <div class="mt-3">
								<input type="file" name="file">
							</div>

		                    <button type="submit" class="btn btn-sm btn-primary mt-4">Add</button>
		            	</form>
					</div>
				</div>
            </div>
			<div class="col-12">
				<div class="bg-dark pl-4 pr-4 pt-2 pb-2">
					<h3 class="display-4 fs-1" style="font-size:30px;color:gray;">Footer</h3>
				</div>
			</div>
        </div>
    </div>

</body>
</html><?php /**PATH C:\Users\janith\Desktop\Continure Oreginal\project-2\resources\views/admin/index.blade.php ENDPATH**/ ?>