

<?php $__env->startSection('content'); ?>

    <form class="form-signup" method="post" action="<?php echo e(route('register.perform')); ?>">

        <input type="hidden" name="_token" value="<?php echo e(csrf_token()); ?>" />
        <img  src="<?php echo url('images/loo.png'); ?>" alt="" width="200" height="100">
        
        <h1 class="h3 mb-3 fw-normal"style="font-family: impact; font-style: blod;">Register</h1>
        <p style="font-family: monospace;"> Create your account it's free only take minute.</p>

        <div class="form-group >
            <div class="row">
                <div col-md-6>
            <input type="email" class="form-control" name="email" value="<?php echo e(old('email')); ?>" placeholder="name@example.com" required="required" autofocus>
            <label for="floatingEmail" style="font-family: monospace;">Email address</label>
            <?php if($errors->has('email')): ?>
                <span class="text-danger text-left"><?php echo e($errors->first('email')); ?></span>
            <?php endif; ?>
                </div>
            </div>
        </div>

        <div class="form-group">
            <div class="row">
                <div col-md-6>
            <input type="text" class="form-control" name="username" value="<?php echo e(old('username')); ?>" placeholder="Username" required="required" autofocus>
            <label for="floatingName"style="font-family: monospace;">Username</label>
            <?php if($errors->has('username')): ?>
                <span class="text-danger text-left"><?php echo e($errors->first('username')); ?></span>
            <?php endif; ?>
                </div>
            </div>
        </div>
        
        <div class="form-group">
            <div class="row">
                <div col-md-6>
            <input type="password" class="form-control" name="password" value="<?php echo e(old('password')); ?>" placeholder="Password" required="required">
            <label for="floatingPassword" style="font-family: monospace;">Password</label>
            <?php if($errors->has('password')): ?>
                <span class="text-danger text-left"><?php echo e($errors->first('password')); ?></span>
            <?php endif; ?>
                </div>
            </div>
        </div>

        <div class="form-group ">
            <div class="row">
                <div col-md-6>
            <input type="password" class="form-control" name="password_confirmation" value="<?php echo e(old('password_confirmation')); ?>" placeholder="Confirm Password" required="required">
            <label for="floatingConfirmPassword" style="font-family:monospace">Confirm Password</label>
            <?php if($errors->has('password_confirmation')): ?>
                <span class="text-danger text-left"><?php echo e($errors->first('password_confirmation')); ?></span>
            <?php endif; ?>
                </div>
            </div>
        </div>

        <div class="form-group">
            <label>
                <input type="checkbox" name="">
                I accept the <a href="#">Terms of use </a>&<a href=#>"Privacy policy"</a>
            </label>
        </div>

        <input type="submit" class="btn btn-success btn-blo" name="" value="Register">
        
       
    </form>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.auth-master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Janith\Desktop\project\project\resources\views/auth/register.blade.php ENDPATH**/ ?>