<div class="header-background">
        <div id="nav" class="sticky-nav">
            <nav class="navbar navbar-expand-lg ">
  <div class="container">
    <a class="navbar-brand" href="index.html"><img src="<?php echo e(url('/images/loo.png')); ?>"style="color:blue ; width: 200px;"></a>
    
      <?php if(auth()->guard()->check()): ?>
        <?php echo e(auth()->user()->name); ?>

        <div class="text-end">
          <a href="<?php echo e(route('logout.perform')); ?>" class="btn btn-outline-warning">Logout</a>
        </div>
      <?php endif; ?>
      <?php if(auth()->guard()->guest()): ?>
        <div class="text-end">
          <a href="<?php echo e(route('login.perform')); ?>" class="btn btn-outline-light me-2">Login</a>
          <a href="<?php echo e(route('register.perform')); ?>" class="btn btn-warning">Sign-up</a>
        </div>
      <?php endif; ?>
    </div>
  </div>
</nav><?php /**PATH C:\Users\Isuru\Desktop\project\project\resources\views/layouts/partials/navbar.blade.php ENDPATH**/ ?>