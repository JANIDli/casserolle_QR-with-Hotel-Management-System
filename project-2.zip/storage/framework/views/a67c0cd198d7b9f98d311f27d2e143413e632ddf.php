[<?php echo e($slot); ?>](<?php echo e($url); ?>)
<?php /**PATH C:\Users\sheron\Desktop\Edit 02\project\vendor\laravel\framework\src\Illuminate\Mail/resources/views/text/header.blade.php ENDPATH**/ ?>