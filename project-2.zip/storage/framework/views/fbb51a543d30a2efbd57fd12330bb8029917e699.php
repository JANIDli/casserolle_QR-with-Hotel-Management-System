


<?php $__env->startSection('content'); ?>

    
        <h1 style="color:white;" >Please verify your email address</h1>
        
        <?php if(session('resent')): ?>
            <div  class="alert alert-success" style="color:#007C00;" role="alert">
                A fresh verification link has been sent to your email address.
            </div>
        <?php endif; ?>
       <p style="color:#F9B301;font-family: 'Roboto', sans-serif;"
> Before proceeding, please check your email for a verification link. If you did not receive the email,</p>
        <form action="<?php echo e(route('verification.resend')); ?>" method="POST" class="d-inline">
            <?php echo csrf_field(); ?>
          <button type="submit" class="btn btn-outline-success" style="font-family: 'Roboto', sans-serif;"> Click here to request another</button>


        </form>
                       


    
    <style>
       .j{
       background-size: cover;
       background-size: contain;
       background-color: black;     
       height: auto;
       }

        
    </style>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app-master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Isuru\Downloads\project\project\resources\views/verification/notice.blade.php ENDPATH**/ ?>