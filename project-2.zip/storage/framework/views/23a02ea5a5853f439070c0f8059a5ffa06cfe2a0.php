

<?php $__env->startSection('content'); ?>
 
    
        <?php if(auth()->guard()->check()): ?>
        <h1 style="font-family: impact;font-size: 80px; color:white;">C A S S E R O L L</h1>
        <p class="lead" style="color:white;font-family: monospace;">Proceed to order food</p>
        <a href="<?php echo e(route('dashboard.index')); ?>" class="btn btn-lg btn-warning me-2">Lest Go</a>
       
        <?php endif; ?>

        <?php if(auth()->guard()->guest()): ?>
        <h1 style="color:white; font-size:80px; font-family: 'Berkshire Swash', cursive;">We Make Delicious Food</h1>
        <p class="lead" style="color: #F7B80C;font-size:35px; font-family: 'Nerko One', cursive;
">Log in or register frist to order food</p>
        <?php endif; ?>
    
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app-master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\sheron\Downloads\YOO\project-2\resources\views/home/index.blade.php ENDPATH**/ ?>