<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Document</title>
</head>
<body>
    <h2>Order added</h2>
</body>
</html><?php /**PATH C:\Users\sheron\Downloads\YOO\project-2\resources\views/order/orders.blade.php ENDPATH**/ ?>