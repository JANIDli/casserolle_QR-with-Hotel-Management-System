<!DOCTYPE html>
<html lang="en">
<head>
<title>The Menu</title>
<meta charset="utf-8">
<meta http-equiv="X-UA-Compatible" content="IE=edge">
<meta name="description" content="The Venue template project">
<meta name="viewport" content="width=device-width, initial-scale=1">
<link rel="stylesheet" type="text/css" href="styles/bootstrap-4.1.2/bootstrap.min.css">
<link href="plugins/font-awesome-4.7.0/css/font-awesome.min.css" rel="stylesheet" type="text/css">
<link rel="stylesheet" type="text/css" href="plugins/OwlCarousel2-2.2.1/owl.carousel.css">
<link rel="stylesheet" type="text/css" href="plugins/OwlCarousel2-2.2.1/owl.theme.default.css">
<link rel="stylesheet" type="text/css" href="plugins/OwlCarousel2-2.2.1/animate.css">
<link href="plugins/jquery-datepicker/jquery-ui.css" rel="stylesheet" type="text/css">
<link href="plugins/jquery-timepicker/jquery.timepicker.css" rel="stylesheet" type="text/css">
<link rel="stylesheet" type="text/css" href="styles/menu.css">
<link rel="stylesheet" type="text/css" href="styles/menu_responsive.css">
</head>
<body>

<div class="super_container">
	
	<!-- Header -->

	<header class="header">
		<div class="container">
			<div class="row">
				<div class="col">
					<div class="header_content d-flex flex-row align-items-center justify-content-start">
						<div class="logo">
							 <a class="navbar-brand" href="index.html"><img class="logo" src="images/loo.png"></a>
						</div>
						<nav class="main_nav">
							<ul class="d-flex flex-row align-items-center justify-content-start">
								<li><a href="index.html">home</a></li>
								<li><a href="#">about us</a></li>
								<li><a href="menuu.html">menu</a></li>
								<li><a href="#">Contact</a></li>
							</ul>
						</nav>
						<div class="reservations_phone ml-auto"><svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" class="bi bi-cart" viewBox="0 0 16 16">
  <path d="M0 1.5A.5.5 0 0 1 .5 1H2a.5.5 0 0 1 .485.379L2.89 3H14.5a.5.5 0 0 1 .491.592l-1.5 8A.5.5 0 0 1 13 12H4a.5.5 0 0 1-.491-.408L2.01 3.607 1.61 2H.5a.5.5 0 0 1-.5-.5zM3.102 4l1.313 7h8.17l1.313-7H3.102zM5 12a2 2 0 1 0 0 4 2 2 0 0 0 0-4zm7 0a2 2 0 1 0 0 4 2 2 0 0 0 0-4zm-7 1a1 1 0 1 1 0 2 1 1 0 0 1 0-2zm7 0a1 1 0 1 1 0 2 1 1 0 0 1 0-2z"/>
</svg></div>
					</div>
				</div>
			</div>
		</div>
	</header>

	<!-- Hamburger -->
	
	<div class="hamburger_bar trans_400 d-flex flex-row align-items-center justify-content-start">
		<div class="hamburger">
			<div class="menu_toggle d-flex flex-row align-items-center justify-content-start">
				<span>menu</span>
				<div class="hamburger_container">
					<div class="menu_hamburger">
						<div class="line_1 hamburger_lines" style="transform: matrix(1, 0, 0, 1, 0, 0);"></div>
						<div class="line_2 hamburger_lines" style="visibility: inherit; opacity: 1;"></div>
						<div class="line_3 hamburger_lines" style="transform: matrix(1, 0, 0, 1, 0, 0);"></div>
					</div>
				</div>
			</div>
		</div>
	</div>

	<!-- Menu -->

	<div class="menu trans_800">
		<div class="menu_content d-flex flex-column align-items-center justify-content-center text-center">
			<ul>
			<li><a href="index.html">home</a></li>
			<li><a href="#">about us</a></li>
			<li><a href="menuu.html">menu</a></li>
			<li><a href="#">Contact</a></li>
			</ul>
		</div>
		<div class="menu_reservations_phone ml-auto">Cart</div>
	</div>

	<div class="home">
		<div class="parallax_background parallax-window" data-parallax="scroll" data-image-src="images/12.jpg" data-speed="0.8"></div>
		<<div class="home_container">
			<div class="container">
				<div class="row">
					<div class="col">
						<div class="home_content text-center">
							<div class="home_subtitle page_subtitle">Casserole</div>
							<div class="home_title"><h1>Our Menu</h1></div>
						</div>
					</div>
				</div>
			</div>
		</div>
	</div>
</div>

<div class="container">
  <div class="row">
    <div class="col"><button class="button-74" role="button">STARTER</button>
</div>
    <div class="col"><button class="button-74" role="button">SOUP</button></div>
    <div class="col"><button class="button-74" role="button">SALAD</button></div>
    <div class="col"><button class="button-74" role="button">RICE</button></div>
    <div class="col"><button class="button-74" role="button">NASIGORANG</button></div>
    <div class="col"><button class="button-74" role="button">NOODLSE</button></div>
    <div class="col"><button class="button-74" role="button">CHICKEN</button></div>
  </div>
</div>
<div class="container">
  <div class="row">
    <div class="col"><button class="button-74" role="button">FISH</button>
</div>
    <div class="col"><button class="button-74" role="button">PRAWNS</button></div>
    <div class="col"><button class="button-74" role="button">CUTTLEFISH</button></div>
    <div class="col"><button class="button-74" role="button">VEGETABLE</button></div>
    <div class="col"><button class="button-74" role="button">OMELETTE</button></div>
    <div class="col"><button class="button-74" role="button">SETMENU</button></div>
    <div class="col"><button class="button-74" role="button">EXTRAS</button></div>
  </div>
</div>
        

	<script src="js/jquery-3.2.1.min.js"></script>
<script src="styles/bootstrap-4.1.2/popper.js"></script>
<script src="styles/bootstrap-4.1.2/bootstrap.min.js"></script>
<script src="plugins/greensock/TweenMax.min.js"></script>
<script src="plugins/greensock/TimelineMax.min.js"></script>
<script src="plugins/scrollmagic/ScrollMagic.min.js"></script>
<script src="plugins/greensock/animation.gsap.min.js"></script>
<script src="plugins/greensock/ScrollToPlugin.min.js"></script>
<script src="plugins/OwlCarousel2-2.2.1/owl.carousel.js"></script>
<script src="plugins/easing/easing.js"></script>
<script src="plugins/parallax-js-master/parallax.min.js"></script>
<script src="plugins/jquery-datepicker/jquery-ui.js"></script>
<script src="plugins/jquery-timepicker/jquery.timepicker.js"></script>
<script src="js/menu.js"></script>

</body>
</html>
<?php /**PATH C:\Users\Isuru\Downloads\project\project\resources\views/menu/index.blade.php ENDPATH**/ ?>