<?php echo e($slot); ?>

<?php /**PATH C:\Users\sheron\Desktop\Edit 02\project\vendor\laravel\framework\src\Illuminate\Mail/resources/views/text/subcopy.blade.php ENDPATH**/ ?>