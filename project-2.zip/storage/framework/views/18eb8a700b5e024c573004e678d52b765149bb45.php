<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Home page</title>
    <link rel="stylesheet" type="text/css" href="<?php echo e(url('/assets/bootstrap/css/bootstrap.min.css')); ?>">
    <link rel="stylesheet" type="text/css" href="<?php echo e(url('/styles.css')); ?>">
    <script src="js/bootstrap.js"></script>

</head>
<body>

    <div class="header-background">
        <div id="nav" class="sticky-nav">
            <nav class="navbar navbar-expand-lg ">
  <div class="container">
    <a class="navbar-brand" href="index.html"><img src="<?php echo e(url('/images/loo.png')); ?>"style="color:blue;"></a>
<button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
      <span class="navbar-toggler-icon"></span>
    </button>
    <div class="collapse navbar-collapse" id="navbarSupportedContent">
      <ul class="navbar-nav  ml-auto mb-2 mb-lg-0">
        <li class="nav-item">
          <a class="nav-link active" aria-current="page" href="index.html"style="color: white;">HOME</a>
        </li>
        <li class="nav-item">
          <a class="nav-link" href="#"style="color: white;">ABOUT US</a>
        </li>
         <li class="nav-item">
          <a class="nav-link" href="#"style="color: white;">MENU</a>
        </li>
          <li class="nav-item">
          <a class="nav-link" href="#"style="color: white;">CONTACT</a>
        </li>
          <li class="nav-item">
          <a class="nav-link" href="#" style="color: white;">REVIEW</a>
        </li>
      </ul>   
    </div>
  </div>
</nav>  
</div>

</div>
<div id="HOME">
    <div class="landing-text">
       <img src="<?php echo e(url('/images/m.png')); ?>" class="imgg" >
        <h2 style="word-spacing: 30px;"><b>ARE YOU HUNGRY? DON'T WAIT</b> </h2>
        <a href="#" class="btn btn-default btn-lg">View Menu</a>
    </div>
</div>
<div class="paddings">
<div class="container">
    <div class="row">
        
    </div>
    
</div>
    
</div>



</body>
</html>
<?php /**PATH C:\Users\Janith\Desktop\project\project\resources\views/dashboard/index.blade.php ENDPATH**/ ?>