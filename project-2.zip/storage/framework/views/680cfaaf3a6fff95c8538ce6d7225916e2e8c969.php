<?php echo e($slot); ?>

<?php /**PATH C:\Users\janith\Desktop\Continure Oreginal\project-2\vendor\laravel\framework\src\Illuminate\Mail/resources/views/text/footer.blade.php ENDPATH**/ ?>