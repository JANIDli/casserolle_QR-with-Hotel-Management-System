<!DOCTYPE html>
<html lang="en">
    <head>
        <title>The Menu</title>
        <meta charset="utf-8">
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <meta name="description" content="The Venue template project">
        <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>" />
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.6.2/dist/css/bootstrap.min.css"
        integrity="sha384-xOolHFLEh07PJGoPkLv1IbcEPTNtaed2xpHsD9ESMhqIYd0nLMwNLD69Npy4HI+N" crossorigin="anonymous">
        <link href="/plugins/font-awesome-4.7.0/css/font-awesome.min.css" rel="stylesheet" type="text/css">
        <link rel="stylesheet" type="text/css" href="/plugins/OwlCarousel2-2.2.1/owl.carousel.css">
        <link rel="stylesheet" type="text/css" href="/plugins/OwlCarousel2-2.2.1/owl.theme.default.css">
        <link rel="stylesheet" type="text/css" href="/plugins/OwlCarousel2-2.2.1/animate.css">
        <link href="plugins/jquery-datepicker/jquery-ui.css" rel="stylesheet" type="text/css">
        <link href="plugins/jquery-timepicker/jquery.timepicker.css" rel="stylesheet" type="text/css">
        <link rel="stylesheet" type="text/css" href="/styles/menu.css">
        <link rel="stylesheet" type="text/css" href="/styles/food.css">
        <link rel="stylesheet" type="text/css" href="/styles/custom.css">
        <link rel="stylesheet" type="text/css" href="/styles/menu_responsive.css">
        <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/animate.css/4.1.1/animate.min.css"/>
        <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.1.1/css/all.min.css">
    </head>

    <style>
        body{
            background-color: rgb(255, 255, 255);
        }

        .priceP{
            margin-left: 15px;
        }

    </style>
<body>
    <div class="super_container">
        <!-- Header -->
        <header class="header" style="background: rgb(247, 244, 214)">
            <div class="container">
                <div class="row">
                    <div class="col">
                        <div class="header_content d-flex flex-row align-items-center justify-content-start">
                            <div class="logo">
                                 <a class="navbar-brand" href="index.html"><img class="logo" src="images/loo.png"></a>
                            </div>
                            <nav class="main_nav">
                                <ul class="d-flex flex-row align-items-center justify-content-start">
                                    <li><a href="dashboard">home</a></li>
                                    <li><a href="#">about us</a></li>
                                    <li><a href="menuu.html">menu</a></li>
                                    <li><a href="#">Contact</a></li>
                                </ul>
                            </nav>
                            <ul class="navbar-nav ml-auto">
                                <li class="nav-item">
                                  <a class="nav-link" href="#">
                                    <i class="fa fa-shopping-cart" style="color:rgb(0, 0, 0);"></i>
                                  </a>
                                </li>
                              </ul>
                        </div>
                    </div>
                </div>
            </div>
        </header>

        <!-- Hamburger -->

        <div class="hamburger_bar trans_400 d-flex flex-row align-items-center justify-content-start">
            <div class="hamburger">
                <div class="menu_toggle d-flex flex-row align-items-center justify-content-start">
                    <span>menu</span>
                    <div class="hamburger_container">
                        <div class="menu_hamburger">
                            <div class="line_1 hamburger_lines" style="transform: matrix(1, 0, 0, 1, 0, 0);"></div>
                            <div class="line_2 hamburger_lines" style="visibility: inherit; opacity: 1;"></div>
                            <div class="line_3 hamburger_lines" style="transform: matrix(1, 0, 0, 1, 0, 0);"></div>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <!-- Menu -->

        <div class="menu trans_800">
            <div class="menu_content d-flex flex-column align-items-center justify-content-center text-center">
                <ul>
                <li><a href="index.html">home</a></li>
                <li><a href="#">about us</a></li>
                <li><a href="menuu.html">menu</a></li>
                <li><a href="#">Contact</a></li>
                </ul>
            </div>
            <div class="menu_reservations_phone ml-auto">Cart</div>
        </div>
        <br>
        <br>

        <div class="container">
            <div class="row align-items-center "  >

                <?php $__currentLoopData = $items; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="col-lg-6 d-flex align-items-center shadow-sm p-2 border mb-2">
                        <div class="col-sm-4">
                            <div class="card" >
                                  <img class="card-img-top" src="images/1.jpg" alt="Card image cap">
                             </div>
                         </div>
                        <div class="col-sm-2"><h5 class="mb-0"><?php echo e($item->name); ?></h5></div>
                        <div class="col-sm-2 ml-3 text-danger"><span><?php echo e($item->price); ?>/=</span></div>
                        <div class="col-sm-2"><i class="fas fa-trash" style="color:black;"></i> </div>
                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

            </div>
            <br>
             <br>

            <div class="row justify-content-center">
                <div class="col col-lg-3">
                    <!-- eMPTY -->
                </div>
                <div class="col-md-6">
                    <div class="card">
                        <div class="card-body">
                            <form action="/order/new" method="POST">
                                <?php echo csrf_field(); ?>
                                <div class="form-group">
                                <select id="foodselection" onchange="hideElement()" class="form-control">
                                    <option value="dinein">Dine In</option>
                                    <option value="takeaway">TakeAway</option>
                                  </select>
                                </div>

                                <div class="form-group" id="myElement">
                                  <select id="" class="form-control" name="table">
                                    <option selected disabled>Select Table</option>
                                    <option value="1">Tabele 01</option>
                                    <option value="2">Table  02</option>
                                    <option value="3">Table  03</option>
                                    <option value="4">Table  04</option>
                                    <option value="5">Table  05</option>
                                    <option value="6">Table  06</option>
                                    <option value="7">Table  07</option>
                                  </select>
                                </div>
                                <input type="hidden" value="<?php echo e($items_ids); ?>">
                                <div class="form-group">
                                    <label for="comment">Comment:</label>
                                    <textarea class="form-control" rows="5" id="comment" name="comment"></textarea>
                                  </div>
                                  <div>
                                    <button type=submit>Proceed</button>
                                  </div>
                            </form>
                          </div>
                    </div>

                </div>

              


              <form action="<?php echo e(url('cash_order')); ?>" method="get">
                <?php echo csrf_field(); ?>
                <input type="text" name="city">

                <button type="submit">PROGRESS </button>

              </form>

            </div>
        </div>


<script src="js/jquery-3.2.1.min.js"></script>
<script src="styles/bootstrap-4.1.2/popper.js"></script>
<script src="styles/bootstrap-4.1.2/bootstrap.min.js"></script>
<script src="plugins/greensock/TweenMax.min.js"></script>
<script src="plugins/greensock/TimelineMax.min.js"></script>
<script src="plugins/scrollmagic/ScrollMagic.min.js"></script>
<script src="plugins/greensock/animation.gsap.min.js"></script>
<script src="plugins/greensock/ScrollToPlugin.min.js"></script>
<script src="plugins/OwlCarousel2-2.2.1/owl.carousel.js"></script>
<script src="plugins/easing/easing.js"></script>
<script src="plugins/parallax-js-master/parallax.min.js"></script>
<script src="plugins/jquery-datepicker/jquery-ui.js"></script>
<script src="plugins/jquery-timepicker/jquery.timepicker.js"></script>
<script src="js/menu.js"></script>

<script>

    // Get Food method Selection //////////////////////////

function hideElement() {
    var selection = document.getElementById("foodselection");
    var element = document.getElementById("myElement");

    if (selection.value === "TakeAway") {
      element.style.display = "none";
    } else {
      element.style.display = "block";
    }
  }

</script>
</body>
</html><?php /**PATH C:\Users\janith\Desktop\Continure Oreginal\project-2\resources\views/Cart/cart.blade.php ENDPATH**/ ?>