<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" type="text/css" href= "<?php echo e(url('/styles/bootstrap-4.1.2/bootstrap.min.css')); ?>">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Admin</title>
</head>
<body>
    <div class="container">
        <div class="row">
            <div class="col-12">
            <form action="/menu/create" method="POST">
                <?php echo csrf_field(); ?>
                <h5>Add menu</h5>
                <input type="text" name="name" placeholder="Menu" class="form-control">
                <button type=submit>Add</button>
            </form>

            <form action="/food/create" method="POST" class="mt-4" enctype="multipart/form-data">
                <?php echo csrf_field(); ?>
                    <h5>Add food</h5>
                    <input class="form-control" type="text" name="name" placeholder="Name">
                    <textarea class="form-control" name="description" id="" cols="30" rows="10" placeholder="Description"></textarea>
                    <input class="form-control" type="number" name="price" placeholder="price">
                    <input type="file" name="image">

                    <button type="submit">Add</button>
            </form>
            </div>
        </div>
    </div>
    
</body>
</html><?php /**PATH C:\Users\janith\Desktop\edit\project\project\resources\views/admin/index.blade.php ENDPATH**/ ?>