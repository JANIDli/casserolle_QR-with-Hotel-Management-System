<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

class TotaluserController extends Controller
{
    public function index()
    {
        return view ('hodgsagdhjagdhjagdgash');
    }
}
